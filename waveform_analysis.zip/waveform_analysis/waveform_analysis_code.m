%% read data and do some pre-processing

core_init = load("/Users/vns0170/Downloads/VenusAnalysis/Figure2_MeanTraces/Core_CrossAligned_DA/Core_CrossAligned_d7.mat");
vmshell_init = load("/Users/vns0170/Downloads/VenusAnalysis/Figure2_MeanTraces/vmShell_CrossAligned_DA/vmShell_CrossAligned_d7.mat");
core = core_init.GroupMeanPsthArrayA;
vmshell = vmshell_init.GroupMeanPsthArrayA;
[~, win] = size(core);
start_ts = -25.;
end_ts = 20.0010;
ts = linspace(start_ts, end_ts, win);
ts_idx = find((ts>=-5) & (ts<=15));
ts_new = ts(1,ts_idx);
comp_idx = find((ts_new>=0) & (ts_new<=5));
[~, win_new] = size(ts_new);
ts_vmshell_idx = find((ts>=5) & (ts<=20));
core = core(:,ts_idx);
vmshell = vmshell(:, ts_idx);

data.core = core;
data.vmshell = vmshell;

%% set some parameters for analysis
sig = .05;
filter_window = 100;
sampling_rate = 1017.25;
freq_c = sampling_rate / (2 * filter_window);
consec_thresh = ceil(sampling_rate / freq_c);

% Graphing parameters
ylims = [-2 4.5];
xlims = [-5 15];
sig_plot_level = linspace(4.3,3.5,8);
savefolder = ...
   '/Users/vns0170/Downloads/Current/ERTReal';

%% run waveform analysis (boot-strapped confidence interval)
[n_core,ev_win] = size(data.core);
[n_vmshell,~] = size(data.vmshell);
timeline = ts_new;

core_t_crit = tinv(1-sig/2,n_core-1);
vmshell_t_crit = tinv(1-sig/2,n_vmshell-1);

mean_core = mean(data.core,1);
sem_core = sem(data.core);
core_bCI = boot_CI(data.core,2000,sig);
[adjLCI,adjUCI] = CI_adjust(core_bCI(1,:),core_bCI(2,:),[],n_core,2);
core_bCIexp = [adjLCI;adjUCI];

mean_vmshell = mean(data.vmshell,1);
sem_vmshell = sem(data.vmshell);
vmshell_bCI = boot_CI(data.vmshell,2000,sig);
[adjLCI,adjUCI] = CI_adjust(vmshell_bCI(1,:),vmshell_bCI(2,:),[],n_vmshell,2);
vmshell_bCIexp = [adjLCI;adjUCI];

diff_bCI = boot_diffCI(data.core,data.vmshell,2000,sig);
[adjLCI,adjUCI] = CI_adjust(diff_bCI(1,:),diff_bCI(2,:),[],n_vmshell,2);
diff_bCIexp = [adjLCI;adjUCI];

%% Significance bars

%bCI
core_bCIexp_sig = NaN(1,ev_win);
sig_idx = find((core_bCIexp(1,:) > 0) | (core_bCIexp(2,:) < 0));
consec = consec_indices(sig_idx,consec_thresh);
core_bCIexp_sig(sig_idx(consec)) = sig_plot_level(2);

vmshell_bCIexp_sig = NaN(1,ev_win);
sig_idx = find((vmshell_bCIexp(1,:) > 0) | (vmshell_bCIexp(2,:) < 0));
consec = consec_indices(sig_idx,consec_thresh);
vmshell_bCIexp_sig(sig_idx(consec)) = sig_plot_level(4);

diff_bCIexp_sig = NaN(1,ev_win);
sig_idx = find((diff_bCIexp(1,:) > 0) | (diff_bCIexp(2,:) < 0));
consec = consec_indices(sig_idx,consec_thresh);
diff_bCIexp_sig(sig_idx(consec)) = sig_plot_level(6);


%% Plot
figure; hold on
plot(timeline,mean_vmshell,'Color',col_rep(3))
errorplot3(mean_vmshell(1:3:end)-sem_vmshell(1:3:end),mean_vmshell(1:3:end)+sem_vmshell(1:3:end),xlims,col_rep(3),.15)

plot(timeline,mean_core,'Color',col_rep(2))
errorplot3(mean_core(1:3:end)-sem_core(1:3:end),mean_core(1:3:end)+sem_core(1:3:end),xlims,col_rep(2),.15)

%Plot bCI sig
plot(timeline,core_bCIexp_sig,'Color',col_rep(2),'Marker','.')
text(xlims(1),sig_plot_level(1),'\bf Core bCI','Color',col_rep(2));
plot(timeline,vmshell_bCIexp_sig,'Color',col_rep(3),'Marker','.')
text(xlims(1),sig_plot_level(3),'\bf vmShell bCI','Color',col_rep(3));
plot(timeline,diff_bCIexp_sig,'Color',col_rep(4),'Marker','.')
text(xlims(1),sig_plot_level(5),'\bf Diff bCI','Color',col_rep(4));

plot([0 0],ylims,'k:')
plot(xlim,[0 0],'k--')

xlim(xlims);
ylim(ylims);

print ('-vector','/Users/vns0170/Downloads/Day7', '-dsvg', '-r300');
